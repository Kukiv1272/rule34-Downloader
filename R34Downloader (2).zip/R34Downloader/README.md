# rule34 Downloader — WPF / C#

## Требования
- Windows 10/11 x64
- [.NET 8 SDK](https://dotnet.microsoft.com/download/dotnet/8.0)

## Структура проекта
```
R34Downloader/
├── R34Downloader.csproj   — проект
├── App.xaml / App.xaml.cs — точка входа, ресурсы (цвета, стили)
├── MainWindow.xaml        — разметка главного окна
├── MainWindow.xaml.cs     — обработчики событий, логика UI
├── Downloader.cs          — вся логика загрузки (HTTP, XML, индексы)
└── r34_icon.ico           — (опционально) иконка рядом с .csproj
```

## Сборка

### Debug (для разработки)
```
cd R34Downloader
dotnet run
```

### Публикация в один .exe
```
cd R34Downloader
dotnet publish -c Release
```
Файл появится в:
`R34Downloader\bin\Release\net8.0-windows\win-x64\publish\r34_downloader.exe`

## Зависимости
Только встроенные в .NET 8 — никаких NuGet-пакетов.

`System.Windows.Forms` используется только для `FolderBrowserDialog`
(входит в .NET 8 Windows Desktop Runtime).
